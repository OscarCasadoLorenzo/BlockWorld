package model.exceptions;

import java.lang.Exception;

/**
 *	@author Oscar Casado Lorenzo
 */

/**
 * The Class StackSizeException.
 */
public class StackSizeException extends Exception{
	
	/**
	 * Instantiates a new stack size exception.
	 */
	public StackSizeException(){
		
	}
}
