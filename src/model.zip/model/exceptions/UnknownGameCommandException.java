package model.exceptions;

/**
 *	@author Oscar Casado Lorenzo
 */

/**
 * The Class UnknownGameCommandException.
 */
public class UnknownGameCommandException {

}
