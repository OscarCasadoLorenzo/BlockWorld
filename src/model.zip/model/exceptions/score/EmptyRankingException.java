package model.exceptions.score;

/**
 *	@author Oscar Casado Lorenzo
 */

/**
 * The Class EmptyRankingException.
 */
public class EmptyRankingException extends Exception{
	
	/**
	 * Instantiates a new empty ranking exception.
	 */
	public EmptyRankingException() {
		
	}
}
